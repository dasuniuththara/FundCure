import 'package:flutter/material.dart';

//on board colours

const tOnBoardingPage1Color = Color(0xFF1CBF72);
const tOnBoardingPage2Color = Color(0xFF1CBF72);
const tOnBoardingPage3Color = Color(0xFF1CBF72);
const tOnBoardingPage4Color = Color(0xFF1CBF72);

//
const Color bgWhite = Color(0xFFFFFFFF);
const Color textlight = Color(0xFF000000);
const Color maingreen = Color(0xFF1CBF72);
