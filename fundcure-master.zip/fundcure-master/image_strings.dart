



//onboarding screen images

const String tOnBoardingImage1 = "assets/images/01.png";
const String tOnBoardingImage2 = "assets/images/02.png";
const String tOnBoardingImage3 = "assets/images/03.png";
const String tOnBoardingImage4 = "assets/images/04.png";
