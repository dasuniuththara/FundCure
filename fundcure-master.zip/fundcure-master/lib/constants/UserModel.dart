//create user with uid

class UserModel {
  final String uid;
  UserModel({required this.uid});
}